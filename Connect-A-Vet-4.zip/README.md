# Connect A Vet 4

Full-stack veterinary directory app using Vue + Vite (frontend) and Node.js + Express (backend).

## Frontend
```bash
cd frontend
npm install
npm run dev
```

## Backend
```bash
cd backend
npm install
node index.js
```

## Deployment
- Frontend: Deploy via Vercel
- Backend: Deploy via Render