<template>
  <div id="app">
    <h1>Connect A Vet 4</h1>
    <div v-for="vet in vets" :key="vet.id" class="vet-card">
      <h2>{{ vet.name }}</h2>
      <p><strong>Location:</strong> {{ vet.location }}</p>
      <p><strong>Specialty:</strong> {{ vet.specialty }}</p>
      <p><strong>Rating:</strong> {{ vet.rating }}</p>
      <p><strong>Status:</strong> {{ vet.openNow ? 'Open' : 'Closed' }}</p>
    </div>
  </div>
</template>
<script>
import axios from 'axios';
export default {
  data() {
    return {
      vets: []
    };
  },
  mounted() {
    axios.get('http://localhost:3000/api/vets')
      .then(res => this.vets = res.data)
      .catch(err => console.error('API error:', err));
  }
}
</script>
<style>
.vet-card { margin-bottom: 20px; padding: 10px; border: 1px solid #ccc; }
</style>